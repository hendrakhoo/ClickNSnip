USE shoppingcartdb;
INSERT INTO `tb_shopping_cart` VALUES (2,NULL,NULL,8),(4,NULL,NULL,10);

