CREATE USER 'go2shop' IDENTIFIED WITH mysql_native_password BY 'go2shop';
GRANT ALL PRIVILEGES ON *.* TO 'go2shop';