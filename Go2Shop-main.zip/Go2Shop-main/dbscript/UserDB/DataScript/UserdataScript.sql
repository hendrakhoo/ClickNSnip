USE userdb;

INSERT INTO `userdb`.`tb_user` (`ID`, `CARD_NUMBER`, `NAME`, `EXPIRY`, `ADDRESS`, `CONTACT_DETAIL`) VALUES ('1', '1', 'haoming', '1', '1', '1');
INSERT INTO `userdb`.`tb_user` (`ID`, `CARD_NUMBER`, `NAME`, `EXPIRY`, `ADDRESS`, `CONTACT_DETAIL`) VALUES ('2', '2', 'go2shop', '2', '2', '2');
