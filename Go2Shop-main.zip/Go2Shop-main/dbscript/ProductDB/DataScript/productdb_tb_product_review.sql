
USE productdb;
INSERT INTO `tb_product_review` VALUES (1,'Seller respond very quickly. Product looks good',5,1,1),(2,'Prompt replies from seller but not many product varieties. Delivery is quite slow. Take about 7 days to deliver.',4,1,2);
