# Auth-service

<p>https://segmentfault.com/a/1190000023483069</p>

<h3>issue:</h3>
<p>1. Post in controller return 403 while GET ok, solved: https://stackoverflow.com/questions/50486314/how-to-solve-403-error-in-spring-boot-post-request</p>

