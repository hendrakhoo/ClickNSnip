export enum PAYMENT_OPTIONS {
    'PAYNOW' = 'PN',
    'CARD' = 'C'
}