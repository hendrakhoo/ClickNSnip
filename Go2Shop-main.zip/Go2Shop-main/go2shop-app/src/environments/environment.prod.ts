export const environment = {
  production: true,
  secret: 'Z28yc2hvcFNlY3JldEtleQ=='
};
